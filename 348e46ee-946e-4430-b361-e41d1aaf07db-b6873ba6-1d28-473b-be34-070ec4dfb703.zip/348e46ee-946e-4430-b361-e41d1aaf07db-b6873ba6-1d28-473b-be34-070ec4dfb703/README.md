# 348e46ee-946e-4430-b361-e41d1aaf07db-b6873ba6-1d28-473b-be34-070ec4dfb703
Repository for Teams Project code and project management
